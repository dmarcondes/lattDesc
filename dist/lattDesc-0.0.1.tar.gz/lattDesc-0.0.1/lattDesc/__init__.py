"""
 Python package `lattDesc` provides functions to run lattice descent algorithms.
 """
